from .canvas_robot import CanvasRobot, LocalDAL, Answer,ENROLLMENT_TYPES, STUDADMIN, \
    EDUCATIONS, COMMUNITIES, SHORTNAMES
