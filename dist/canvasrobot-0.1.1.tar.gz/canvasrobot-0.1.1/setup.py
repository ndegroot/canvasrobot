# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['canvasrobot', 'canvasrobot.entities']

package_data = \
{'': ['*']}

install_requires = \
['canvasapi>=3.0.0,<3.1.0',
 'ipython>=8.4.0,<9.0.0',
 'kneed>=0.8.1,<0.9.0',
 'matplotlib>=3.6.0,<3.7.0',
 'numpy>=1.23.3,<1.24.0',
 'openpyxl>=3.0.10,<4.0.0',
 'pandas>=1.4.2,<2.0.0',
 'plotly>=5.9.0,<6.0.0',
 'pyaml>=21.10.1,<22.0.0',
 'pydal>=20220814.1,<20220815.0',
 'requests>=2.28.1,<2.29.0',
 'rich>=12.5.1,<13.0.0',
 'scikit-learn>=1.1.1,<2.0.0',
 'seaborn>=0.12.0,<0.13.0',
 'word2quiz @ ../word2quiz']

setup_kwargs = {
    'name': 'canvasrobot',
    'version': '0.1.1',
    'description': '',
    'long_description': None,
    'author': 'Nico de Groot',
    'author_email': 'n.c.degroot@tilburguniversity.edu',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
