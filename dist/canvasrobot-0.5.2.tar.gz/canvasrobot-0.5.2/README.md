# CanvasRobot
Library which uses
[Canvasapi](https://canvasapi.readthedocs.io/en/stable/getting-started.html)
to provide a CanvasRobot class.
Used in word2quiz library.

[![PyPI version](https://badge.fury.io/py/canvasrobot.svg)]