from dataclasses import dataclass
from typing import TypeVar, Generic, List, Dict, Tuple

from .course import Course
from .user import User
from .guest import Guest


@dataclass
class EnrollDTO:
    username: str
    course: str
    role: str
    user_id: int = 0
    course_id: int = 0


@dataclass
class SearchTextInCourseDTO:
    course_id: int = 0
    course: str = ""
    search: str = ""


@dataclass
class QuizDTO:
    title: str
    description: str
    quiz_type: str = 'practice_quiz'


AnswerOptions = Dict[str, int]  # answer_text, answer_weigth
# complete list of params : https://canvas.instructure.com/doc/api/quiz_questions.html


@dataclass
class QuestionDTO:
    answers: List[AnswerOptions]
    question_name: str = ""
    question_type: str = 'multiple_choice_question'  # other option essay question
    question_text: str = ''
    points_possible: str = '1.0'
    correct_comments: str = ''
    incorrect_comments: str = ''
    neutral_comments:  str = ''
    correct_comments_html: str = ''
    incorrect_comments_html: str = ''
    neutral_comments_html: str = ''
